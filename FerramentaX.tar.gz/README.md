# FerramentaX

Ferramenta X:
  
  Esta é uma ferramenta destinada a otimização do estudo por vestibulandos ou qualquer outro que esteja em processo de aprendizagem. 
  Ela se baseia no cadastro de matérias e questões que são repetidas de acordo com sua taxa de acertos, erros, e tempo decorrido desde a última resolução, dessa forma ele seleciona a questão que vc mais precisa responder de acordo com tais caracteŕisticas (coeficiente de seleção: indice de acertos/indice de erros * tempo decorrido desde a ultima resolução). 
  Ela é uma plataforma que é adaptada especificamente pra uma pessoa ou um grupo de pessoas que ascessem as mesmas questões, uma vez que não há filtro de questões por usuário, sendo assim, o controle de usuário apenas permite que as questões não sejam acessadas por quem não têm  permissão.


Ferramenta X:

  This is a tool designed to optimize the study by aplications, tests or any other that is in the process of learning.
  It is based on the registration of matters and questions that are repeated according to their rate of correctness, errors, and elapsed time since the last resolution, thus it selects the question that you most need to answer according to these characteristics (selection coefficient : Index of correctness / index of errors * elapsed since the last resolution).
  It is a platform that is tailored specifically for a person or a group of people who have the same questions for study, since there is no per-user filtering of questions, so that user control only not allows that anyone can access the plataform.
