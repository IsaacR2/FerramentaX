<?php
require("validaSessao.php");
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
	<title>Ferramenta X</title>
	<meta charset="UTF-8">
	<style type="text/css">
		img {
			width: 100%;
		}
		.right {
			position: relative;
			right: 0px;

		}
	</style>
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
	<script src="ckeditor/ckeditor.js"></script>
	<!-- <script>
		$(document).ready(function(){
			$("#altTemas").click(function(){			    
			    //$(location).attr('href', 'cadQuest.php?qtdeTemas=' + $("#numTemas").value());
			    window.location.href = "http://seusite.com"+$("#numTemas").value();
			});
		});				
	</script> -->
	<script type="text/javascript">
		function teste() {
			var tempo = document.getElementById('numTemas').value;			
			window.location.href = 'cadQuest.php?qtdeTemas=' + tempo;
		}
	</script>

</head>
<body>
	<?php
	require("template.php");
	require("db/conexao.php");
	require("db/questoes_db2.php");
	require_once("db/materia_db.php");
	require_once("db/topico_db.php");
	require_once("db/assunto_db.php");
	if (!isset($_GET["IdQuest"])) {
		echo "<script type='text/javascript'>window.location.href = 'todasQuestoes.php'</script>";
	}

	/*
	$assuntos = listarTodasAssuntoPorQuestao($conn, $id);
	$materias = listarTodasMateriaPorQuestao($conn, $id);
	$topicos = listarTodasTopicoPorQuestao($conn, $id);

	$numMat = NumVincPorQuestaoAssunto($conn, $_GET["IdQuest"]);
	$numTop = NumVincPorQuestaoMateria($conn, $_GET["IdQuest"]);
	$numAssu = NumVincPorQuestaoTopico($conn, $_GET["IdQuest"]);
	$maior = max($numMat,$numTop,$numAssu);
	$id = $_GET["IdQuest"];

	if (!isset($_GET["qtdeTemas"])) {	
		echo "<script type='text/javascript'>window.location.href = 'cadQuest.php?qtdeTemas=$maior&IdQuest=$id'</script>"
	}

	$assuntos = listarTodasAssuntoPorQuestao($conn, $id);
	$materias = listarTodasMateriaPorQuestao($conn, $id);
	$topicos = listarTodasTopicoPorQuestao($conn, $id);
	$tabela = array();
	$i=-1;	
	foreach ($materias as $linha) {
		$j=0;
		$i++;
		$tabela[$i][$j] = $linha
		foreach ($topicos as $linha2) {
			if ($linha2['materia'] == $linha['id']) {
				$j++;
				$tabela[$i][$j] = $linha2;
				foreach ($assunto as $linha3) {
					if ($linha3['topico'] == $linha2) {
						# code...
					}
				}
			}
		}
	}

	*/
	$questao = listarQuestao($conn, $_GET["IdQuest"]);
	?>	
	<div class="container" align="center">
		<div id="cabecalho" align="left">
			<h3>Bem vindo</h3>
		</div>
		<div class="row">
			<div id="comentario" align="left" class="col-xs-10 well">
				<h3>Alterar Questão</h3><br />
				<form name="formulario1" action="proc/proc_alterarQuestao.php" method="POST">
					<h4>Temas</h4><br />
					<div id="temas" class="col-md-12">
						<div class="well col-md-4">
							<table class="table table-condensed">
								<thead>
									<tr>
										<th>Remover</th>
										<th>Adicionar</th>
									</tr>
								</thead>
								<tbody>
									<tr>
										<td><a href="removerQuestaoMateria.php?IdQuest=<?php echo  $_GET['IdQuest']; ?>">Remover Materias</a></td>
										<td><a href="addQuestaoMateria.php?IdQuest=<?php echo  $_GET['IdQuest']; ?>"> Adicionar Materias</a><br /></td>
									</tr>
									<tr>
										<td><a href="removerQuestaoTopico.php?IdQuest=<?php echo  $_GET['IdQuest']; ?>">Remover Topicos</a></td>
										<td><a href="addQuestaoTopico.php?IdQuest=<?php echo  $_GET['IdQuest']; ?>"> Adicionar Topicos</a><br /></td>
									</tr>
									<tr>
										<td><a href="removerQuestaoAssunto.php?IdQuest=<?php echo  $_GET['IdQuest']; ?>">Remover Assuntos</a></td>
										<td><a href="addQuestaoAssunto.php?IdQuest=<?php echo  $_GET['IdQuest']; ?>"> Adicionar Assuntos</a><br /></td>
									</tr>
								</tbody>
							</table>						
						</div>
					</div>
					<br />
					<div class="col-md-12">					
						<h4>Coeficiente</h4><br />					
						<input type="number" min="0.01" class="form-control" step="0.01" name="NCoef" placeholder="Digite a matéria para adiciaonar..." value="<?php echo $questao['coeficiente']; ?>" required />
					</div>
					<br />
					<div class="col-md-12">
						<h4>Questão</h4><br />					
						<textarea name="NTexto" id="NTexto" style="resize:none" rows="10"><?php echo $questao['texto']; ?></textarea>
						<script>
						  CKEDITOR.replace( 'NTexto' );
						</script>
					</div>
					<br />
					<div class="col-md-12">
						<h4>Resposta</h4><br />	
						<textarea name="NResp" id="NResp" style="resize:none" rows="5"><?php echo $questao['resposta']; ?></textarea> 
						<script>
						  CKEDITOR.replace( 'NResp' );
						</script>
					</div>
					<br />
					<div class="col-md-12">
						<input type="hidden" name="Nid" value="<?php echo $questao['id']; ?>">
						<button class="btn btn-default pull-right" type="submit">Adicionar</button>
					</div>
				</form>
			</div> 
		</div>
		  
	</div>
</body>
</html>			